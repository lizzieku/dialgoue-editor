import React from 'react';

export default function App() {
  return <h1>Hello from Dialogue Editor!</h1>;
}